# JPG to Sketsa - Versi Windows

Port dari aplikasi Android v4.8: 3 langkah (Sketsa -> Hapus Latar -> SpeedPaint), semua berjalan offline di PC.

## Cara pakai (paling mudah)
1. Pasang Python 3.10+ dari python.org (centang "Add python.exe to PATH").
2. Klik dua kali `run.bat`. Pertama kali ia memasang paket otomatis (butuh internet), setelah itu aplikasi terbuka.

## Membuat JPGtoSketsa.exe
- Di PC: jalankan `build_exe.bat` -> hasil di `dist\JPGtoSketsa\JPGtoSketsa.exe`.
- Atau lewat GitHub: unggah folder ini ke repo, tab Actions > "Build Windows" > unduh artifact.

## Model AI (diunduh otomatis, sekali saja, ke %LOCALAPPDATA%\JPGtoSketsa\models)
- Hapus latar: isnet-general-use.onnx (~180 MB), menggantikan ML Kit di Android.
- Garis AI (mode "Arsir + AI"): u2net_portrait.onnx (~170 MB). Jika unduhan gagal, klik "Model AI..." lalu pilih berkas
  u2net_portrait.onnx yang sama dengan yang Anda pakai di build Android. Tanpa model ini, mode Arsir tetap jalan.
- Super-resolusi (sr_x4.onnx) sudah termasuk.

Hasil disimpan di Pictures\JPG to Sketsa dan Videos\SpeedPaint (bisa diganti lewat "Pilih Folder Simpan").
Video dibuat dengan FFmpeg (H.264 MP4), termasuk dalam paket imageio-ffmpeg.
