@echo off
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>nul && (set PY=py -3) || (set PY=python)
%PY% -m venv .venv-build
call .venv-build\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r requirements.txt pyinstaller
pyinstaller --noconfirm --windowed --name JPGtoSketsa --add-data "assets;assets" --collect-all imageio_ffmpeg --collect-all onnxruntime main.py
echo.
echo Selesai. Aplikasi ada di folder dist\JPGtoSketsa  (jalankan JPGtoSketsa.exe)
pause
