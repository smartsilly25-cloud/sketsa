"""Model AI offline lewat ONNX Runtime: garis portrait (U2-Net Portrait), super-resolusi (Real-ESRGAN x4v3),
dan segmentasi objek (ISNet / U2-Netp) untuk Hapus Latar.

Model besar diunduh sekali saja ke  %LOCALAPPDATA%\\JPGtoSketsa\\models  lalu dipakai offline.
"""
from __future__ import annotations

import shutil
import threading
import urllib.request
from pathlib import Path
from typing import Callable, Optional

import cv2
import numpy as np

from .common import asset_path, models_dir, to_rgba

ProgressCb = Optional[Callable[[str, float], None]]

PORTRAIT_FILE = "u2net_portrait.onnx"
PORTRAIT_URLS = [
    "https://storage.googleapis.com/ailia-models/u2net_portrait/u2net_portrait.onnx",
]
SEG_MODELS = {
    # nama: (berkas, url, ukuran input, mean, std)
    "isnet": ("isnet-general-use.onnx",
              "https://github.com/danielgatis/rembg/releases/download/v0.0.0/isnet-general-use.onnx",
              1024, (0.485, 0.456, 0.406), (1.0, 1.0, 1.0)),
    "u2netp": ("u2netp.onnx",
               "https://github.com/danielgatis/rembg/releases/download/v0.0.0/u2netp.onnx",
               320, (0.485, 0.456, 0.406), (0.229, 0.224, 0.225)),
}

_lock = threading.RLock()


def _providers():
    import onnxruntime as ort
    av = ort.get_available_providers()
    # DirectML (GPU Windows) bila paket onnxruntime-directml terpasang; jika tidak CPU.
    pv = [p for p in ("DmlExecutionProvider",) if p in av] + ["CPUExecutionProvider"]
    return pv


def _session(path: Path):
    import onnxruntime as ort
    so = ort.SessionOptions()
    so.intra_op_num_threads = 0   # otomatis: pakai semua inti
    so.log_severity_level = 3
    try:
        return ort.InferenceSession(str(path), so, providers=_providers())
    except Exception:
        return ort.InferenceSession(str(path), so, providers=["CPUExecutionProvider"])


def download(urls, dest: Path, progress: ProgressCb = None, min_bytes: int = 1_000_000) -> bool:
    """Unduh ke dest (lewat berkas .part). True jika berhasil."""
    if isinstance(urls, str):
        urls = [urls]
    tmp = dest.with_suffix(dest.suffix + ".part")
    last_err = None
    for url in urls:
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "JPGtoSketsa/4.8"})
            with urllib.request.urlopen(req, timeout=60) as r, open(tmp, "wb") as f:
                total = int(r.headers.get("Content-Length") or 0)
                got = 0
                while True:
                    chunk = r.read(1 << 20)
                    if not chunk:
                        break
                    f.write(chunk)
                    got += len(chunk)
                    if progress and total:
                        progress(f"Mengunduh model {dest.name}: {got * 100 // total}%", got / total)
            if tmp.stat().st_size < min_bytes:
                raise IOError("berkas terlalu kecil")
            tmp.replace(dest)
            return True
        except Exception as e:  # noqa: BLE001
            last_err = e
            try:
                tmp.unlink()
            except OSError:
                pass
    download.last_error = str(last_err)
    return False


download.last_error = ""


# ============================================================ garis portrait
class AiPortrait:
    S = 512
    _session_obj = None
    _cache_key = None
    _cache_raw = None
    last_error = ""
    progress: ProgressCb = None

    @classmethod
    def path(cls) -> Path:
        return models_dir() / PORTRAIT_FILE

    @classmethod
    def available(cls) -> bool:
        return cls.path().exists() and cls.path().stat().st_size > 1_000_000

    @classmethod
    def install_from(cls, src: str) -> None:
        shutil.copyfile(src, cls.path())
        cls._session_obj = None

    @classmethod
    def ensure(cls, allow_download: bool = True) -> bool:
        if cls.available():
            return True
        if not allow_download:
            return False
        ok = download(PORTRAIT_URLS, cls.path(), cls.progress, min_bytes=50_000_000)
        if not ok:
            cls.last_error = ("Model garis AI belum ada & unduhan gagal (" + download.last_error +
                              "). Taruh berkas u2net_portrait.onnx di: " + str(models_dir()))
        return ok

    @classmethod
    def _sess(cls):
        if cls._session_obj is None:
            cls._session_obj = _session(cls.path())
        return cls._session_obj

    @staticmethod
    def _key(img: np.ndarray) -> int:
        h, w = img.shape[:2]
        ys = ((np.arange(16) * 2 + 1) * (h - 1) // 32)
        xs = ((np.arange(16) * 2 + 1) * (w - 1) // 32)
        return hash((w, h, img[ys][:, xs, :3].tobytes()))

    @classmethod
    def lines(cls, src: np.ndarray):
        """Kecerahan 0..255 per piksel (ukuran sama dengan src): putih = kertas, gelap = goresan. None bila gagal."""
        with _lock:
            try:
                if not cls.ensure():
                    return None
                S = cls.S
                src = to_rgba(src)
                h, w = src.shape[:2]
                sc = S / max(w, h)
                nw, nh = max(1, round(w * sc)), max(1, round(h * sc))
                offX, offY = (S - nw) // 2, (S - nh) // 2
                key = cls._key(src)
                if cls._cache_raw is None or key != cls._cache_key:
                    sess = cls._sess()
                    inp = sess.get_inputs()[0]
                    small = cv2.resize(src[..., :3], (nw, nh), interpolation=cv2.INTER_AREA if sc < 1 else cv2.INTER_LINEAR)
                    ys = np.clip(np.arange(S) - offY, 0, nh - 1)
                    xs = np.clip(np.arange(S) - offX, 0, nw - 1)
                    sq = small[ys][:, xs]                                   # SxSx3 RGB
                    nchw = len(inp.shape) == 4 and inp.shape[1] == 3
                    if "uint8" in inp.type:
                        x = sq[..., ::-1]                                    # model Android: BGR, NHWC uint8
                        x = np.ascontiguousarray(x[None])
                        if nchw:
                            x = np.ascontiguousarray(x.transpose(0, 3, 1, 2))
                        raw = sess.run(None, {inp.name: x})[0]
                        raw = np.asarray(raw).reshape(-1)[: S * S].reshape(S, S)
                        raw = raw.astype(np.float32)
                    else:
                        im = sq.astype(np.float32)
                        im = im / max(float(im.max()), 1e-6)
                        im = (im - np.array([0.485, 0.456, 0.406], np.float32)) / np.array([0.229, 0.224, 0.225], np.float32)
                        x = im.transpose(2, 0, 1)[None] if nchw else im[None]
                        out = np.asarray(sess.run(None, {inp.name: np.ascontiguousarray(x, np.float32)})[0])
                        d = out.reshape(-1)[: S * S].reshape(S, S).astype(np.float32)
                        d = 1.0 - d                                          # garis gelap di atas kertas putih
                        d = (d - d.min()) / max(float(d.max() - d.min()), 1e-6)
                        raw = d * 255.0
                    cls._cache_raw, cls._cache_key = raw, key
                raw = cls._cache_raw
                crop = raw[offY:offY + nh, offX:offX + nw]
                out = cv2.resize(crop, (w, h), interpolation=cv2.INTER_LINEAR)
                cls.last_error = ""
                return np.clip(out, 0, 255)
            except Exception as e:  # noqa: BLE001
                cls.last_error = f"{type(e).__name__}: {e}"
                return None


# ============================================================ super-resolusi
class SuperRes:
    TILE = 160
    PAD = 12
    _session_obj = None
    _cache_key = None
    _cache_img = None
    last_error = ""

    @classmethod
    def upscale4(cls, src: np.ndarray):
        with _lock:
            try:
                src = to_rgba(src)
                key = AiPortrait._key(src)
                if cls._cache_img is not None and key == cls._cache_key:
                    return cls._cache_img
                if cls._session_obj is None:
                    cls._session_obj = _session(asset_path("sr_x4.onnx"))
                sess = cls._session_obj
                name = sess.get_inputs()[0].name
                h, w = src.shape[:2]
                rgb = src[..., :3].astype(np.float32) / 255.0
                out = np.zeros((h * 4, w * 4, 3), np.uint8)
                T, P = cls.TILE, cls.PAD
                for ty in range(0, h, T):
                    for tx in range(0, w, T):
                        x1, y1 = min(w, tx + T), min(h, ty + T)
                        ex0, ey0 = max(0, tx - P), max(0, ty - P)
                        ex1, ey1 = min(w, x1 + P), min(h, y1 + P)
                        tile = np.ascontiguousarray(rgb[ey0:ey1, ex0:ex1].transpose(2, 0, 1)[None])
                        res = sess.run(None, {name: tile})[0][0]             # 3 x th*4 x tw*4
                        sy0, sx0 = (ty - ey0) * 4, (tx - ex0) * 4
                        part = res[:, sy0:sy0 + (y1 - ty) * 4, sx0:sx0 + (x1 - tx) * 4]
                        out[ty * 4:y1 * 4, tx * 4:x1 * 4] = np.clip(part.transpose(1, 2, 0) * 255.0 + 0.5, 0, 255).astype(np.uint8)
                img = to_rgba(out)
                cls._cache_img, cls._cache_key = img, key
                cls.last_error = ""
                return img
            except Exception as e:  # noqa: BLE001
                cls.last_error = f"{type(e).__name__}: {e}"
                return None


# ============================================================ segmentasi objek
class Segmenter:
    _sessions: dict = {}
    last_error = ""
    progress: ProgressCb = None

    @classmethod
    def _load(cls, which: str):
        if which in cls._sessions:
            return cls._sessions[which]
        fname, url, size, mean, std = SEG_MODELS[which]
        p = models_dir() / fname
        if not p.exists() or p.stat().st_size < 1_000_000:
            if not download(url, p, cls.progress):
                raise RuntimeError("unduh model gagal: " + download.last_error)
        cls._sessions[which] = (_session(p), size, mean, std)
        return cls._sessions[which]

    @classmethod
    def mask(cls, src: np.ndarray):
        """Peta keyakinan objek 0..1 (HxW float32). None bila model tidak bisa dipakai."""
        with _lock:
            for which in ("isnet", "u2netp"):
                try:
                    sess, size, mean, std = cls._load(which)
                    src = to_rgba(src)
                    h, w = src.shape[:2]
                    im = cv2.resize(src[..., :3], (size, size), interpolation=cv2.INTER_LANCZOS4).astype(np.float32)
                    im = im / max(float(im.max()), 1e-6)
                    im = (im - np.array(mean, np.float32)) / np.array(std, np.float32)
                    x = np.ascontiguousarray(im.transpose(2, 0, 1)[None], np.float32)
                    out = sess.run(None, {sess.get_inputs()[0].name: x})[0]
                    m = np.asarray(out).reshape(-1)[: size * size].reshape(size, size).astype(np.float32)
                    m = (m - m.min()) / max(float(m.max() - m.min()), 1e-6)
                    cls.last_error = ""
                    return cv2.resize(m, (w, h), interpolation=cv2.INTER_CUBIC).clip(0, 1)
                except Exception as e:  # noqa: BLE001
                    cls.last_error = f"{which}: {type(e).__name__}: {e}"
            return None
