"""Antarmuka Windows (Tkinter): 3 langkah - Sketsa, Hapus Latar, SpeedPaint."""
from __future__ import annotations

import os
import threading
import time
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

import numpy as np
from PIL import Image, ImageTk

from . import bg_remover as bg
from . import speedpaint as sp
from . import square_extend as se
from .ai_models import AiPortrait, Segmenter, SuperRes
from .common import (asset_path, data_dir, default_output_dir, load_image, models_dir, on_checker,
                     resize_max, save_image, to_rgba)
from .sketcher import SketchParams, render, render_hd

YELLOW, INK, BG, MUTED = "#FFC107", "#111111", "#FFF8E7", "#6B6558"
VERSION = "4.8 Windows"

MODES = ["Arsir", "Arsir + AI", "Arsir Berwarna + AI"]
MODE_IDS = [3, 4, 5]
PAPERS = ["Kertas putih", "Kertas krem", "Papan tulis (kapur)", "Transparan (PNG, hanya garis)"]
FORMATS = ["Persegi 1:1 - perluas latar (tanpa memotong)", "Persegi 1:1 - kertas polos (tanpa memotong)", "Sesuai foto asli"]
CUT_METHODS = ["Objek (AI)", "Warna latar (latar polos / langit)", "Gabungan (paling bersih)"]
CUT_INKS = ["Warna asli", "Hitam (hanya garis, kertas transparan)", "Putih (hanya garis, kertas transparan)",
            "Hitam, isi objek opak (garis tidak hilang)"]


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f"JPG to Sketsa {VERSION}")
        self.geometry("1180x800")
        self.minsize(980, 640)
        self.configure(bg=BG)
        try:
            self.iconphoto(True, tk.PhotoImage(file=str(asset_path("logo_header.png"))))
        except Exception:
            pass

        self.src_path: str | None = None
        self.base: np.ndarray | None = None          # foto pratinjau (<=900)
        self.result: np.ndarray | None = None        # sketsa (foto asli)
        self.result_sq: np.ndarray | None = None     # sketsa persegi
        self.cut_mask: bg.Mask | None = None
        self.cut_result: np.ndarray | None = None
        self.cut_show: np.ndarray | None = None
        self.save_dir: str | None = None
        self.video_path: str | None = None
        self.gen = 0
        self.cut_gen = 0
        self.photo_gen = 0
        self.cut_busy = False
        self.cancel_flag = False
        self.showing_original = False
        self._after = None
        self._tkimg = None
        self.custom_hand: np.ndarray | None = None

        self._build()
        AiPortrait.progress = self._model_progress
        Segmenter.progress = self._model_progress

    # ------------------------------------------------------------------ UI util
    def _build(self):
        st = ttk.Style(self)
        try:
            st.theme_use("clam")
        except tk.TclError:
            pass
        st.configure("TNotebook", background=BG)
        st.configure("TNotebook.Tab", padding=(14, 8), font=("Segoe UI", 10, "bold"))
        st.map("TNotebook.Tab", background=[("selected", YELLOW)])
        st.configure("Y.TButton", font=("Segoe UI", 10, "bold"), background=YELLOW, foreground=INK, padding=8)
        st.map("Y.TButton", background=[("active", "#ffd54f"), ("disabled", "#e8dcae")])
        st.configure("W.TButton", font=("Segoe UI", 10), padding=6)
        st.configure("TLabelframe", background=BG)
        st.configure("TLabelframe.Label", background=BG, font=("Segoe UI", 10, "bold"))
        st.configure("TLabel", background=BG)
        st.configure("TCheckbutton", background=BG)

        left = tk.Frame(self, bg=BG)
        left.pack(side="left", fill="both", expand=True, padx=(10, 5), pady=10)
        right = tk.Frame(self, bg=BG, width=430)
        right.pack(side="right", fill="y", padx=(5, 10), pady=10)
        right.pack_propagate(False)

        self.logo = None
        try:
            lg = Image.open(asset_path("logo_header.png")).convert("RGBA")
            lg.thumbnail((200, 90))
            self.logo = ImageTk.PhotoImage(lg)
            tk.Label(left, image=self.logo, bg=BG).pack()
        except Exception:
            pass
        ttk.Button(left, text="Pilih Foto...", style="Y.TButton", command=self.pick_photo).pack(fill="x", pady=4)
        self.canvas = tk.Canvas(left, bg="#F4EFE0", highlightthickness=2, highlightbackground=INK)
        self.canvas.pack(fill="both", expand=True)
        self.canvas.bind("<Configure>", lambda e: self.update_preview())
        self.canvas.bind("<ButtonPress-1>", self._hold_orig)
        self.canvas.bind("<ButtonRelease-1>", self._release_orig)
        tk.Label(left, text="Tahan klik pada gambar untuk melihat foto asli", fg=MUTED, bg=BG).pack(anchor="w")
        self.folder_lbl = tk.Label(left, anchor="w", bg=BG, fg=INK, justify="left", wraplength=560)
        self.folder_lbl.pack(fill="x", pady=(6, 0))
        fr = tk.Frame(left, bg=BG)
        fr.pack(fill="x")
        ttk.Button(fr, text="Pilih Folder Simpan", style="W.TButton", command=self.pick_folder).pack(side="left")
        ttk.Button(fr, text="Folder Bawaan", style="W.TButton", command=self.reset_folder).pack(side="left", padx=6)
        ttk.Button(fr, text="Model AI...", style="W.TButton", command=self.model_dialog).pack(side="right")
        self.refresh_folder()

        self.nb = ttk.Notebook(right)
        self.nb.pack(fill="both", expand=True)
        self.nb.bind("<<NotebookTabChanged>>", self._tab_changed)
        self.t_sketch = self._scroll_tab("1. Sketsa")
        self.t_cut = self._scroll_tab("2. Hapus Latar")
        self.t_paint = self._scroll_tab("3. SpeedPaint")
        self._build_sketch(self.t_sketch)
        self._build_cut(self.t_cut)
        self._build_paint(self.t_paint)

        self.status = tk.Label(self, text=f"JPG to Sketsa {VERSION}  -  Sketsa > Hapus Latar > SpeedPaint", bg=BG, fg=MUTED, anchor="w")
        self.status.pack(side="bottom", fill="x", padx=10)

    def _scroll_tab(self, title):
        outer = tk.Frame(self.nb, bg=BG)
        self.nb.add(outer, text=title)
        cv = tk.Canvas(outer, bg=BG, highlightthickness=0)
        sb = ttk.Scrollbar(outer, orient="vertical", command=cv.yview)
        inner = tk.Frame(cv, bg=BG)
        inner.bind("<Configure>", lambda e: cv.configure(scrollregion=cv.bbox("all")))
        win = cv.create_window((0, 0), window=inner, anchor="nw")
        cv.bind("<Configure>", lambda e: cv.itemconfigure(win, width=e.width))
        cv.configure(yscrollcommand=sb.set)
        cv.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        cv.bind("<Enter>", lambda e: cv.bind_all("<MouseWheel>", lambda ev: cv.yview_scroll(int(-ev.delta / 120), "units")))
        cv.bind("<Leave>", lambda e: cv.unbind_all("<MouseWheel>"))
        return inner

    def _box(self, parent, title):
        f = ttk.LabelFrame(parent, text=title, padding=8)
        f.pack(fill="x", padx=6, pady=5)
        return f

    def _combo(self, parent, label, items, sel=0, cb=None):
        ttk.Label(parent, text=label, foreground=MUTED).pack(anchor="w", pady=(6, 0))
        v = tk.StringVar(value=items[sel])
        c = ttk.Combobox(parent, textvariable=v, values=items, state="readonly")
        c.pack(fill="x")
        c.items = items
        c.idx = lambda c=c: c.items.index(c.get())
        if cb:
            c.bind("<<ComboboxSelected>>", lambda e: cb())
        return c

    def _slider(self, parent, fmt, lo, hi, init, cb=None):
        row = tk.Frame(parent, bg=BG)
        row.pack(fill="x", pady=(6, 0))
        lbl = tk.Label(row, bg=BG, anchor="w")
        lbl.pack(fill="x")
        var = tk.IntVar(value=init)

        def on(_=None):
            lbl.config(text=fmt(var.get()))
            if cb:
                cb()

        sc = ttk.Scale(row, from_=lo, to=hi, variable=var, orient="horizontal", command=lambda v: (var.set(int(float(v))), on()))
        sc.pack(fill="x")
        lbl.config(text=fmt(init))
        sc.var = var
        sc.row = row
        sc.get_i = lambda: var.get()
        return sc

    def set_status(self, t):
        self.after(0, lambda: self.status.config(text=t))

    def _model_progress(self, text, frac):
        self.set_status(text)

    # ------------------------------------------------------------------ tab Sketsa
    def _build_sketch(self, p):
        c = self._box(p, "Gaya sketsa")
        self.mode_cb = self._combo(c, "Gaya", MODES, 1, self._mode_changed)
        c = self._box(p, "Atur hasil")
        self.auto_var = tk.BooleanVar(value=True)
        r = tk.Frame(c, bg=BG)
        r.pack(fill="x")
        ttk.Radiobutton(r, text="Auto", variable=self.auto_var, value=True, command=self._auto_changed).pack(side="left")
        ttk.Radiobutton(r, text="Manual", variable=self.auto_var, value=False, command=self._auto_changed).pack(side="left", padx=10)
        self.manual_vals = [40, 70, 75, 55]
        self.sk_blur = self._slider(c, lambda v: f"Ketebalan / kehalusan garis: {v}%", 0, 100, 30, self.schedule)
        self.sk_dark = self._slider(c, lambda v: f"Kegelapan: {v}%", 0, 100, 35, self.schedule)
        self.sk_color = self._slider(c, lambda v: f"Kekuatan warna: {v}%", 0, 100, 75, self.schedule)
        self.sk_grain = self._slider(c, lambda v: f"Tekstur kertas: {v}%", 0, 100, 45, self.schedule)
        self.sk_paper = self._combo(c, "Latar kertas", PAPERS, 0, self.schedule)
        self.sk_format = self._combo(c, "Format hasil", FORMATS, 0, self.schedule)
        a = tk.Frame(p, bg=BG)
        a.pack(fill="x", padx=6, pady=8)
        self.sk_save = ttk.Button(a, text="Simpan Sketsa", style="Y.TButton", command=self.save_sketch)
        self.sk_save.pack(fill="x")
        self.sk_open = ttk.Button(a, text="Buka Folder Hasil", style="W.TButton", command=self.open_folder)
        self.sk_open.pack(fill="x", pady=3)
        ttk.Button(a, text="Lanjut: Hapus Latar >", style="W.TButton", command=lambda: self.nb.select(1)).pack(fill="x")
        ttk.Button(a, text="Langsung ke SpeedPaint >", style="W.TButton",
                   command=lambda: (self.sp_src.set(self.sp_src.items[1]), self.nb.select(2))).pack(fill="x", pady=3)
        self._auto_changed()

    def _mode_changed(self):
        if self.mode >= 4 and not AiPortrait.available():
            self.set_status("Model garis AI akan diunduh saat pertama dipakai (sekitar 170 MB). Atau pasang manual lewat tombol 'Model AI...'")
        self._auto_changed()

    @property
    def mode(self):
        return MODE_IDS[self.mode_cb.idx()]

    def _auto_changed(self):
        sbs = [self.sk_blur, self.sk_dark, self.sk_color, self.sk_grain]
        auto = self.auto_var.get()
        if auto:
            m = self.mode
            v = [30, 35, 60, 45] if m == 5 else ([30, 35, 75, 45] if m >= 3 else [40, 70, 75, 55])
            for s, x in zip(sbs, v):
                s.var.set(x)
        for s in sbs:
            s.state(["disabled"] if auto else ["!disabled"])
        self._relabel(sbs)
        self.schedule()

    def _relabel(self, sbs):
        fm = ["Ketebalan / kehalusan garis: {}%", "Kegelapan: {}%", "Kekuatan warna: {}%", "Tekstur kertas: {}%"]
        for s, f in zip(sbs, fm):
            s.row.winfo_children()[0].config(text=f.format(s.var.get()))
        if self.mode in (1, 5):
            self.sk_color.row.pack(fill="x", pady=(6, 0), after=self.sk_dark.row)
        else:
            self.sk_color.row.pack_forget()

    def square_mode(self):
        return {0: 1, 1: 2, 2: 0}[self.sk_format.idx()]

    def params(self, paper=None):
        return SketchParams(self.mode, self.sk_blur.get_i(), self.sk_dark.get_i(), self.sk_color.get_i(),
                            self.sk_grain.get_i(), self.sk_paper.idx() if paper is None else paper)

    # ------------------------------------------------------------------ foto / pratinjau
    def pick_photo(self):
        p = filedialog.askopenfilename(title="Pilih foto", filetypes=[("Gambar", "*.jpg *.jpeg *.png *.webp *.bmp *.tif *.tiff"), ("Semua", "*.*")])
        if not p:
            return
        try:
            self.src_path = p
            self.base = load_image(p, 900)
        except Exception as e:  # noqa: BLE001
            messagebox.showerror("Gagal membuka foto", str(e))
            return
        self.result = self.result_sq = None
        self.cut_mask = self.cut_result = self.cut_show = None
        self.photo_gen += 1
        self.cut_gen += 1
        self.update_preview()
        self.schedule()
        if self.nb.index("current") == 1:
            self.run_cut()

    def _tab_changed(self, _=None):
        self.update_preview()
        if self.nb.index("current") == 1 and self.base is not None and self.cut_mask is None:
            self.run_cut()

    def _hold_orig(self, _):
        self.showing_original = True
        self.update_preview()

    def _release_orig(self, _):
        self.showing_original = False
        self.update_preview()

    def current_image(self):
        tab = self.nb.index("current")
        if self.showing_original and tab in (0, 1):
            return self.base
        if tab == 0:
            return self.result_sq if self.result_sq is not None else (self.result if self.result is not None else self.base)
        if tab == 1:
            return self.cut_show if self.cut_show is not None else (self.result if self.result is not None else self.base)
        i = self.sp_src.idx()
        if i == 0:
            return self.base
        if i == 1:
            return self.result_sq if self.result_sq is not None else (self.result if self.result is not None else self.base)
        return self.cut_show if self.cut_show is not None else (self.result if self.result is not None else self.base)

    def update_preview(self):
        img = self.current_image()
        self.canvas.delete("all")
        cw, ch = max(10, self.canvas.winfo_width()), max(10, self.canvas.winfo_height())
        if img is None:
            self.canvas.create_text(cw // 2, ch // 2, text="Belum ada foto", fill=MUTED, font=("Segoe UI", 12))
            return
        im = Image.fromarray(img[..., :3] if img.shape[2] == 3 or img[..., 3].min() == 255 else on_checker(img)[..., :3])
        im.thumbnail((cw - 8, ch - 8))
        self._tkimg = ImageTk.PhotoImage(im)
        self.canvas.create_image(cw // 2, ch // 2, image=self._tkimg)

    def schedule(self):
        if self.base is None:
            return
        if self._after:
            self.after_cancel(self._after)
        self._after = self.after(250, self.render_preview)

    def render_preview(self):
        bm = self.base
        if bm is None:
            return
        p = self.params()
        sqm = self.square_mode()
        self.gen += 1
        g = self.gen
        self.set_status("Membuat sketsa...")

        def work():
            try:
                ex = se.apply(bm, sqm) if sqm else None
                full = render_hd(ex.img if ex else bm, p, AiPortrait.lines, SuperRes.upscale4)
                if p.mode >= 4 and AiPortrait.last_error:
                    self.set_status("Garis AI tidak aktif: " + AiPortrait.last_error)
                else:
                    self.set_status("Sketsa siap")
                plain = se.crop_back(full, ex) if (ex and ex.changed) else full

                def done():
                    if g != self.gen:
                        return
                    self.result = plain
                    self.result_sq = full if (ex and ex.changed) else None
                    self.update_preview()
                    if self.cut_mask is not None:
                        self.apply_cut()
                self.after(0, done)
            except Exception as e:  # noqa: BLE001
                self.set_status(f"Gagal: {e}")
        threading.Thread(target=work, daemon=True).start()

    # ------------------------------------------------------------------ simpan
    def out_dir(self, video=False):
        return Path(self.save_dir) if self.save_dir else default_output_dir(video)

    def refresh_folder(self):
        self.folder_lbl.config(text="Disimpan ke: " + (self.save_dir or "folder bawaan (Pictures\\JPG to Sketsa, Videos\\SpeedPaint)"))

    def pick_folder(self):
        d = filedialog.askdirectory(title="Pilih folder simpan")
        if d:
            self.save_dir = d
            self.refresh_folder()

    def reset_folder(self):
        self.save_dir = None
        self.refresh_folder()

    def open_folder(self):
        d = self.out_dir()
        try:
            os.startfile(str(d))  # type: ignore[attr-defined]
        except Exception:
            messagebox.showinfo("Folder hasil", str(d))

    def save_sketch(self):
        if not self.src_path:
            return
        p = self.params()
        sqm = self.square_mode()
        self.set_status("Menyimpan sketsa (resolusi penuh)...")

        def work():
            try:
                big = load_image(self.src_path, 2048)
                ex = se.apply(big, sqm) if sqm else None
                out = render_hd(ex.img if ex else big, p, AiPortrait.lines, SuperRes.upscale4)
                png = p.paper == 3
                f = self.out_dir() / f"sketsa_{int(time.time())}.{'png' if png else 'jpg'}"
                save_image(str(f), out)
                self.set_status(f"Tersimpan: {f}")
            except Exception as e:  # noqa: BLE001
                self.set_status(f"Gagal menyimpan: {e}")
        threading.Thread(target=work, daemon=True).start()

    # ------------------------------------------------------------------ tab Hapus Latar
    def _build_cut(self, p):
        c = self._box(p, "Hapus latar belakang")
        tk.Label(c, bg=BG, fg=MUTED, justify="left", wraplength=360,
                 text='Latar dihapus dari hasil sketsa (langkah 1). Hasil: PNG transparan. Pilih "Transparan" pada Latar kertas di langkah 1 jika ingin garis saja.').pack(anchor="w")
        self.cut_method = self._combo(c, "Metode deteksi", CUT_METHODS, 2, lambda: self._redetect())
        self.cut_ink = self._combo(c, "Warna objek", CUT_INKS, 3, lambda: self.apply_cut())
        ttk.Button(c, text="Deteksi Ulang Objek", style="Y.TButton", command=self._redetect).pack(fill="x", pady=8)
        c = self._box(p, "Atur potongan")
        self.cut_thr = self._slider(c, lambda v: f"Ambang objek: {v}% (naik = lebih ketat)", 0, 100, 50, lambda: self._cut_delay())
        self.cut_soft = self._slider(c, lambda v: f"Kehalusan tepi: {v}%", 0, 100, 30, lambda: self._cut_delay())
        a = tk.Frame(p, bg=BG)
        a.pack(fill="x", padx=6, pady=8)
        ttk.Button(a, text="Simpan PNG Transparan", style="Y.TButton", command=self.save_cut).pack(fill="x")
        ttk.Button(a, text="Lanjut ke SpeedPaint >", style="W.TButton",
                   command=lambda: (self.sp_src.set(self.sp_src.items[2]), self.nb.select(2))).pack(fill="x", pady=3)
        self._cut_after = None

    def _cut_delay(self):
        if self._cut_after:
            self.after_cancel(self._cut_after)
        self._cut_after = self.after(150, self.apply_cut)

    def _redetect(self):
        self.cut_mask = self.cut_result = self.cut_show = None
        if self.base is not None and self.nb.index("current") == 1:
            self.run_cut()

    def run_cut(self):
        bm = self.base
        if bm is None or self.cut_busy:
            return
        self.cut_busy = True
        g = self.photo_gen
        meth = self.cut_method.idx()
        self.set_status("Mendeteksi objek... (pertama kali model diunduh sekitar 180 MB)")

        def work():
            try:
                m = bg.detect(bm, meth)

                def done():
                    self.cut_busy = False
                    if g == self.photo_gen:
                        self.cut_mask = m
                        self.set_status("Memakai deteksi warna latar" + (f" ({Segmenter.last_error})" if Segmenter.last_error else "") if m.fallback else "Objek terdeteksi")
                        self.apply_cut()
                    elif self.nb.index("current") == 1:
                        self.run_cut()
                self.after(0, done)
            except Exception as e:  # noqa: BLE001
                self.cut_busy = False
                self.set_status(f"Gagal: {e}")
        threading.Thread(target=work, daemon=True).start()

    def apply_cut(self):
        r, m = self.result, self.cut_mask
        if r is None or m is None:
            return
        thr, soft, ink = self.cut_thr.get_i(), self.cut_soft.get_i(), self.cut_ink.idx()
        paper = self.sk_paper.idx()
        sqc = self.square_mode()
        self.cut_gen += 1
        g = self.cut_gen

        def work():
            try:
                o0 = bg.recolor(bg.apply(r, m, thr, soft), ink, paper)
                out = se.pad_to_square(o0) if sqc else o0
                shown = on_checker(out, ink == 2)

                def done():
                    if g == self.cut_gen:
                        self.cut_result, self.cut_show = out, shown
                        self.update_preview()
                self.after(0, done)
            except Exception as e:  # noqa: BLE001
                self.set_status(f"Gagal: {e}")
        threading.Thread(target=work, daemon=True).start()

    def finish_cut(self, b, sq):
        return se.pad_to_square(b) if sq else bg.crop_to_content(b)

    def save_cut(self):
        if not self.src_path:
            return
        p = self.params()
        thr, soft, meth, ink, sqc = self.cut_thr.get_i(), self.cut_soft.get_i(), self.cut_method.idx(), self.cut_ink.idx(), self.square_mode()
        self.set_status("Memproses & menyimpan PNG transparan...")

        def work():
            try:
                big = load_image(self.src_path, 2048)
                sk = render(big, p, AiPortrait.lines)
                m = bg.detect(big, meth)
                out = self.finish_cut(bg.recolor(bg.apply(sk, m, thr, soft), ink, p.paper), sqc)
                f = self.out_dir() / f"sketsa_tanpa_latar_{int(time.time())}.png"
                save_image(str(f), out)
                self.set_status(f"Tersimpan (PNG transparan): {f}")
            except Exception as e:  # noqa: BLE001
                self.set_status(f"Gagal menyimpan: {e}")
        threading.Thread(target=work, daemon=True).start()

    # ------------------------------------------------------------------ tab SpeedPaint
    def _build_paint(self, p):
        c = self._box(p, "Sumber gambar")
        self.sp_src = self._combo(c, "Gambar yang dipakai", ["Foto asli", "Hasil sketsa (langkah 1)", "Sketsa tanpa latar (langkah 2)"], 0, self.update_preview)
        c = self._box(p, "Gaya menggambar")
        self.sp_style = self._combo(c, "Gaya", ["Ikuti garis, lalu warna", "Langsung warna (menyapu)", "Ikuti garis saja", "Langsung warna, ikuti garis"])
        self.sp_dir = self._combo(c, "Arah", ["Kiri ke kanan", "Atas ke bawah", "Dari tengah keluar", "Acak alami (per bagian, beda tiap video)"], 3)
        self.sp_paper = self._combo(c, "Latar kertas", ["Putih", "Krem", "Papan tulis", "Kertas buku bergaris"])
        self.sp_ink = self._combo(c, "Warna goresan sketsa", ["Otomatis (hitam / putih)", "Biru tua (pulpen)", "Cokelat sepia", "Abu-abu pensil", "Warna asli foto"])
        c = self._box(p, "Video")
        self.sp_dur = self._slider(c, lambda v: f"Durasi: {v} detik", 5, 60, 15)
        self.sp_ratio = self._combo(c, "Rasio video", ["Sesuai foto", "9:16 (Reels/TikTok)", "1:1 (Instagram)", "16:9 (YouTube)"])
        self.sp_res = self._combo(c, "Resolusi", ["720p", "1080p"])
        self.sp_fps = self._combo(c, "FPS video", ["24 fps", "30 fps", "60 fps"], 1)
        self.sp_hold = self._combo(c, "Tahan hasil akhir", ["0 detik", "1 detik", "2 detik", "3 detik"], 1)
        c = self._box(p, "Deteksi garis")
        self.sp_source = self._combo(c, "Sumber garis", ["Otomatis (hitam-putih / foto)", "Tepi saja (untuk foto)", "Area gelap (gambar hitam-putih)"])
        self.sp_sens = self._combo(c, "Kepekaan garis", ["Otomatis (sesuai gambar)", "Lebih sedikit garis", "Lebih banyak garis"])
        self.sp_thick = self._combo(c, "Ketebalan garis", ["Otomatis (sesuai gambar)", "Tipis", "Sedang", "Tebal"])
        c = self._box(p, "Tangan")
        self.hand_on = tk.BooleanVar(value=True)
        ttk.Checkbutton(c, text="Tampilkan gambar tangan", variable=self.hand_on).pack(anchor="w")
        self.sp_hand = self._slider(c, lambda v: f"Ukuran tangan: {v}%", 20, 100, 55)
        self.sp_speed = self._slider(c, lambda v: f"Kecepatan gerak tangan: x{v / 10:.1f}", 5, 30, 10)
        self.hand_lbl = tk.Label(c, text="Tangan: bawaan", bg=BG, fg=MUTED)
        self.hand_lbl.pack(anchor="w", pady=4)
        r = tk.Frame(c, bg=BG)
        r.pack(fill="x")
        ttk.Button(r, text="Ganti tangan (PNG)", style="W.TButton", command=self.pick_hand).pack(side="left")
        ttk.Button(r, text="Bawaan", style="W.TButton", command=self.reset_hand).pack(side="left", padx=6)
        a = tk.Frame(p, bg=BG)
        a.pack(fill="x", padx=6, pady=8)
        self.gen_btn = ttk.Button(a, text="Buat Video Speedpaint", style="Y.TButton", command=self.start_render)
        self.gen_btn.pack(fill="x")
        self.cancel_btn = ttk.Button(a, text="Batalkan", style="W.TButton", command=self._cancel)
        self.bar = ttk.Progressbar(a, maximum=100)
        self.play_btn = ttk.Button(a, text="Putar Video", style="W.TButton", command=self.play_video)
        self.fold_btn = ttk.Button(a, text="Buka Folder Video", style="W.TButton", command=lambda: self._open(self.out_dir(True)))

    def _open(self, d):
        try:
            os.startfile(str(d))  # type: ignore[attr-defined]
        except Exception:
            messagebox.showinfo("Folder", str(d))

    def pick_hand(self):
        f = filedialog.askopenfilename(title="Pilih gambar tangan (PNG transparan)", filetypes=[("PNG", "*.png"), ("Gambar", "*.png *.webp")])
        if f:
            try:
                self.custom_hand = np.array(Image.open(f).convert("RGBA"))
                self.hand_lbl.config(text="Tangan: gambar pilihan Anda")
            except Exception as e:  # noqa: BLE001
                messagebox.showerror("Gagal", str(e))

    def reset_hand(self):
        self.custom_hand = None
        self.hand_lbl.config(text="Tangan: bawaan")

    def _cancel(self):
        self.cancel_flag = True
        self.set_status("Membatalkan...")

    def play_video(self):
        if self.video_path:
            try:
                os.startfile(self.video_path)  # type: ignore[attr-defined]
            except Exception:
                messagebox.showinfo("Video", self.video_path)

    def start_render(self):
        if not self.src_path:
            messagebox.showinfo("Foto", "Pilih foto dulu.")
            return
        secs = self.sp_dur.get_i()
        src_mode = self.sp_src.idx()
        from_sketch = src_mode >= 1
        cthr, csoft, cmeth, cink = self.cut_thr.get_i(), self.cut_soft.get_i(), self.cut_method.idx(), self.cut_ink.idx()
        sqv = self.square_mode()
        o = sp.PaintOptions(
            style=self.sp_style.idx(), direction=self.sp_dir.idx(), paper=self.sp_paper.idx(),
            ratio=self.sp_ratio.idx(), res=1080 if self.sp_res.idx() == 1 else 720,
            hand_pct=self.sp_hand.get_i(), hand_speed=self.sp_speed.get_i() / 10.0, hold_sec=self.sp_hold.idx(),
            fps=[24, 30, 60][self.sp_fps.idx()], sens=self.sp_sens.idx(), thick=self.sp_thick.idx(),
            source=self.sp_source.idx(), ink=self.sp_ink.idx(), transparent_src=from_sketch)
        sparams = self.params()
        hand = None
        if self.hand_on.get():
            hand = self.custom_hand if self.custom_hand is not None else sp.default_hand()
        outdir = self.out_dir(True)
        self.cancel_flag = False
        self.gen_btn.state(["disabled"])
        self.cancel_btn.pack(fill="x", pady=3)
        self.bar.pack(fill="x", pady=3)
        self.bar["value"] = 0
        self.play_btn.pack_forget()
        self.fold_btn.pack_forget()
        self.set_status("Membuat video...")

        def work():
            try:
                bmp = load_image(self.src_path, 1600)
                if from_sketch:
                    orig = bmp
                    p3 = SketchParams(sparams.mode, sparams.blur, sparams.dark, sparams.color, sparams.grain, 3)
                    base_img = se.apply(orig, sqv).img if (sqv and src_mode == 1) else orig
                    bmp = render(base_img, p3, AiPortrait.lines)
                    if src_mode == 2:
                        self.set_status("Menghapus latar...")
                        m = bg.detect(orig, cmeth)
                        bmp = self.finish_cut(bg.recolor(bg.apply(bmp, m, cthr, csoft), cink, 3), sqv)
                        self.set_status("Membuat video...")
                f = outdir / f"speedpaint_{int(time.time())}.mp4"
                sp.render(bmp, secs, str(f), o, hand, lambda: self.cancel_flag,
                          lambda pr: self.after(0, lambda: self.bar.configure(value=pr)))
                if self.cancel_flag:
                    try:
                        f.unlink()
                    except OSError:
                        pass
                    self.set_status("Dibatalkan")
                else:
                    self.video_path = str(f)
                    self.set_status(f"Selesai! Tersimpan: {f}")
                    self.after(0, lambda: (self.play_btn.pack(fill="x", pady=3), self.fold_btn.pack(fill="x")))
            except Exception as e:  # noqa: BLE001
                self.set_status(f"Gagal: {e}")
            finally:
                self.after(0, lambda: (self.gen_btn.state(["!disabled"]), self.cancel_btn.pack_forget(), self.bar.pack_forget()))
        threading.Thread(target=work, daemon=True).start()

    # ------------------------------------------------------------------ model AI
    def model_dialog(self):
        s = ("Model AI dipakai offline. Berkas disimpan di:\n" + str(models_dir()) + "\n\n"
             f"- Garis AI (u2net_portrait.onnx): {'ADA' if AiPortrait.available() else 'belum ada (diunduh otomatis saat dipakai)'}\n"
             "- Hapus latar (isnet-general-use.onnx): diunduh otomatis saat pertama dipakai\n"
             "- Super-resolusi: sudah termasuk\n\n"
             "Punya berkas u2net_portrait.onnx sendiri? Klik Yes untuk memilihnya.")
        if messagebox.askyesno("Model AI", s):
            f = filedialog.askopenfilename(title="Pilih u2net_portrait.onnx", filetypes=[("ONNX", "*.onnx")])
            if f:
                AiPortrait.install_from(f)
                messagebox.showinfo("Model AI", "Model terpasang.")
                self.schedule()


def main():
    App().mainloop()
