"""Penghapus latar belakang (port dari BackgroundRemover.kt).

Utama: segmentasi objek ONNX (menggantikan ML Kit di Android). Cadangan: warna latar dari tepi foto.
"""
from __future__ import annotations

from dataclasses import dataclass

import cv2
import numpy as np

from .ai_models import Segmenter
from .common import box_blur, to_rgba


@dataclass
class Mask:
    a: np.ndarray          # keyakinan objek 0..1, HxW float32
    fallback: bool


def detect(src: np.ndarray, method: int = 2) -> Mask:
    """method: 0 = Objek (AI), 1 = Warna latar, 2 = Gabungan (AI dirapikan deteksi warna)."""
    if method == 1:
        return _color_mask(src)
    ml = _detect_ai(src)
    if ml is None:
        return _color_mask(src)
    if method == 2:
        c = _color_mask(src)
        if c.a.shape == ml.a.shape:
            # AI yang yakin (>= 0.85) tidak dibatalkan deteksi warna (gaun/kemeja putih di latar terang)
            a = np.where(ml.a >= 0.85, ml.a, np.minimum(ml.a, c.a))
            return Mask(a.astype(np.float32), False)
    return ml


def _detect_ai(src: np.ndarray):
    m = Segmenter.mask(src)
    if m is None:
        return None
    if (m > 0.5).mean() <= 0.005:
        return None
    return Mask(m, False)


def _color_mask(src: np.ndarray) -> Mask:
    src = to_rgba(src)
    h, w = src.shape[:2]
    rgb = src[..., :3].astype(np.int32)
    border = np.concatenate([rgb[0], rgb[-1], rgb[:, 0], rgb[:, -1]], 0)
    mean = border.mean(0).astype(np.int32)
    dev = np.abs(border - mean).sum(1).mean()
    tol = int(np.clip(40 + int(dev) * 2, 40, 140))
    near = (np.abs(rgb - mean).sum(2) <= tol).astype(np.uint8)
    _, lab = cv2.connectedComponents(near, connectivity=4)
    edge_labels = np.unique(np.concatenate([lab[0], lab[-1], lab[:, 0], lab[:, -1]]))
    edge_labels = edge_labels[edge_labels != 0]
    is_bg = np.isin(lab, edge_labels) & (near == 1)
    a = np.where(is_bg, 0.0, 1.0).astype(np.float32)
    a = box_blur(a, max(1, max(w, h) // 400), passes=1)
    return Mask(a, True)


def apply(src: np.ndarray, m: Mask, thr: int, soft: int) -> np.ndarray:
    """alpha akhir = alpha gambar x peta. thr 0..100 (naik = lebih ketat), soft 0..100 (tepi lebih lembut)."""
    src = to_rgba(src)
    h, w = src.shape[:2]
    t = 0.2 + thr / 100.0 * 0.6
    s = 0.02 + soft / 100.0 * 0.4
    lo = t - s / 2.0
    a = m.a
    if a.shape != (h, w):
        a = cv2.resize(a, (w, h), interpolation=cv2.INTER_NEAREST)
    q = np.clip((a - lo) / s, 0, 1)
    q = q * q * (3 - 2 * q)
    out = src.copy()
    out[..., 3] = np.clip(np.floor(src[..., 3].astype(np.float32) * q), 0, 255).astype(np.uint8)
    return out


def recolor(src: np.ndarray, ink: int, paper: int) -> np.ndarray:
    """ink: 0 = warna asli, 1 = hitam, 2 = putih, 3 = hitam + isi objek opak. paper = latar kertas langkah 1."""
    if ink == 0:
        return src
    src = to_rgba(src)
    rgb = src[..., :3].astype(np.float32)
    sa = src[..., 3].astype(np.float32)
    l = 0.299 * rgb[..., 0] + 0.587 * rgb[..., 1] + 0.114 * rgb[..., 2]

    def ink_amt():
        if paper == 2:
            return np.clip((l - 60.0) / 120.0, 0, 1)
        return np.clip((1.0 - l / 255.0 - 0.04) / 0.30, 0, 1)

    out = np.zeros_like(src)
    if ink == 3:
        t = np.clip((sa - 110.0) / 140.0, 0, 1)
        f = t * t * (3 - 2 * t)
        inkamt = ink_amt()
        edge = 255.0 if paper == 2 else 20.0
        a3 = np.clip(np.floor(sa * (inkamt * (1 - f) + f)), 0, 255)
        col = edge * (1 - f)[..., None] + rgb * f[..., None]
        out[..., :3] = np.clip(np.floor(col), 0, 255).astype(np.uint8)
        out[..., 3] = a3.astype(np.uint8)
        out[sa == 0] = 0
        return out

    gray_v = 20 if ink == 1 else 255
    amt = np.ones_like(l) if paper == 3 else ink_amt()
    if paper != 3 and ink == 1:
        amt = np.where(sa >= 200, np.maximum(amt, 0.25), amt)
    na = np.clip(np.floor(sa * amt), 0, 255)
    out[..., :3] = gray_v
    out[..., 3] = na.astype(np.uint8)
    out[sa == 0, :3] = src[sa == 0, :3]
    return out


def crop_to_content(src: np.ndarray, pad_pct: int = 4) -> np.ndarray:
    h, w = src.shape[:2]
    ys, xs = np.where(src[..., 3] > 30)
    if len(ys) == 0:
        return src
    pad = max(w, h) * pad_pct // 100
    x0, x1 = max(0, xs.min() - pad), min(w - 1, xs.max() + pad)
    y0, y1 = max(0, ys.min() - pad), min(h - 1, ys.max() + pad)
    return src[y0:y1 + 1, x0:x1 + 1].copy()
