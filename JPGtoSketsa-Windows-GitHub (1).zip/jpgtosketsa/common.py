"""Fungsi bantu bersama: blur, kurva halus, derau deterministik, lokasi berkas."""
from __future__ import annotations

import os
import sys
from pathlib import Path

import cv2
import numpy as np


# ---------------------------------------------------------------- lokasi berkas
def app_dir() -> Path:
    """Folder aplikasi (mendukung hasil PyInstaller)."""
    if getattr(sys, "frozen", False):
        return Path(getattr(sys, "_MEIPASS", Path(sys.executable).parent))
    return Path(__file__).resolve().parent.parent


def asset_path(name: str) -> Path:
    return app_dir() / "assets" / name


def data_dir() -> Path:
    """Folder data pengguna (model AI yang diunduh, pengaturan)."""
    base = os.environ.get("LOCALAPPDATA") or os.path.join(os.path.expanduser("~"), ".local", "share")
    p = Path(base) / "JPGtoSketsa"
    p.mkdir(parents=True, exist_ok=True)
    return p


def models_dir() -> Path:
    p = data_dir() / "models"
    p.mkdir(parents=True, exist_ok=True)
    return p


def default_output_dir(video: bool = False) -> Path:
    home = Path(os.path.expanduser("~"))
    pics = home / ("Videos" if video else "Pictures")
    p = pics / ("SpeedPaint" if video else "JPG to Sketsa")
    p.mkdir(parents=True, exist_ok=True)
    return p


# ---------------------------------------------------------------- matematika
def rint(x) -> int:
    """Pembulatan seperti Kotlin roundToInt (setengah ke atas)."""
    return int(np.floor(x + 0.5))


def box_blur(a: np.ndarray, r: int, passes: int = 3) -> np.ndarray:
    """Blur kotak berulang (mendekati Gaussian), tepi di-clamp. Input/Output float32."""
    a = a.astype(np.float32, copy=False)
    if r < 1:
        return a.copy()
    k = 2 * r + 1
    out = a
    for _ in range(passes):
        out = cv2.blur(out, (k, k), borderType=cv2.BORDER_REPLICATE)
    return out


def smoothstep(a: float, b: float, x):
    t = np.clip((x - a) / (b - a), 0.0, 1.0)
    return t * t * (3.0 - 2.0 * t)


def logistic(z):
    return 1.0 / (1.0 + np.exp(-1.702 * z))


def hash_rnd(seed: np.ndarray) -> np.ndarray:
    """Derau 0..1 deterministik (sama dengan rnd() di versi Android). seed: int array."""
    x = seed.astype(np.int64).astype(np.uint32)
    x = (x * np.uint32(0x9E3779B1 & 0xFFFFFFFF) + np.uint32(0x2545F491)).astype(np.uint32)
    x = x ^ (x >> np.uint32(15))
    x = (x * np.uint32(0x85EBCA6B)).astype(np.uint32)
    x = x ^ (x >> np.uint32(13))
    x = (x * np.uint32(0xC2B2AE35)).astype(np.uint32)
    x = x ^ (x >> np.uint32(16))
    return (x >> np.uint32(8)).astype(np.float32) / 16777216.0


def zscore(a: np.ndarray) -> np.ndarray:
    m = a.mean()
    sd = max(float(a.std()), 1e-6)
    return (a - m) / sd


# ---------------------------------------------------------------- gambar
def to_rgba(img: np.ndarray) -> np.ndarray:
    if img.ndim == 2:
        img = np.stack([img] * 3, -1)
    if img.shape[2] == 3:
        a = np.full(img.shape[:2] + (1,), 255, np.uint8)
        img = np.concatenate([img, a], 2)
    return np.ascontiguousarray(img)


def load_image(path: str, max_side: int | None = None) -> np.ndarray:
    """Baca gambar (hormati rotasi EXIF) -> RGBA uint8."""
    from PIL import Image, ImageOps

    im = Image.open(path)
    im = ImageOps.exif_transpose(im)
    if im.mode not in ("RGB", "RGBA"):
        im = im.convert("RGBA" if "A" in im.getbands() or im.mode == "P" else "RGB")
    arr = np.array(im)
    if arr.ndim == 2:
        arr = np.stack([arr] * 3, -1)
    arr = to_rgba(arr)
    # Gambar dengan alpha dilebur ke putih (foto sumber tidak punya transparansi)
    a = arr[..., 3:4].astype(np.float32) / 255.0
    if (arr[..., 3] < 255).any():
        rgb = arr[..., :3].astype(np.float32) * a + 255.0 * (1 - a)
        arr = to_rgba(np.clip(rgb + 0.5, 0, 255).astype(np.uint8))
    return resize_max(arr, max_side) if max_side else arr


def resize_max(img: np.ndarray, max_side: int) -> np.ndarray:
    h, w = img.shape[:2]
    m = max(h, w)
    if m <= max_side:
        return img
    s = max_side / m
    return cv2.resize(img, (max(1, int(w * s)), max(1, int(h * s))), interpolation=cv2.INTER_AREA)


def save_image(path: str, img: np.ndarray, jpg_quality: int = 95) -> None:
    from PIL import Image

    p = str(path).lower()
    if p.endswith(".png"):
        Image.fromarray(img, "RGBA").save(path, "PNG")
    else:
        Image.fromarray(img[..., :3], "RGB").save(path, "JPEG", quality=jpg_quality)


def on_checker(img: np.ndarray, dark: bool = False) -> np.ndarray:
    """Gambar transparan di atas pola kotak-kotak (hanya untuk pratinjau)."""
    h, w = img.shape[:2]
    cell = max(8, max(w, h) // 40)
    yy, xx = np.mgrid[0:h, 0:w]
    par = ((yy // cell) + (xx // cell)) % 2
    if dark:
        c0, c1 = 0x4A, 0x30
    else:
        c0, c1 = 0xFF, 0xD9
    bg = np.where(par == 0, c0, c1).astype(np.float32)[..., None]
    a = img[..., 3:4].astype(np.float32) / 255.0
    rgb = img[..., :3].astype(np.float32) * a + bg * (1 - a)
    return to_rgba(np.clip(rgb + 0.5, 0, 255).astype(np.uint8))
