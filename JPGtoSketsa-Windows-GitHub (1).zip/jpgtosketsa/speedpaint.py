"""Video SpeedPaint (port dari SpeedPaint.kt). Penyandi video: FFmpeg (H.264) lewat imageio-ffmpeg."""
from __future__ import annotations

import math
import random
import subprocess
from dataclasses import dataclass

import cv2
import numpy as np

from .common import asset_path, to_rgba

PAPER = [(255, 255, 255), (0xF5, 0xEC, 0xD7), (0x2B, 0x3A, 0x33), (0xF3, 0xEF, 0xE0)]
INK = [(0x22, 0x22, 0x22), (0x3A, 0x2E, 0x1E), (0xF2, 0xF2, 0xF2), (0x22, 0x22, 0x22)]


@dataclass
class PaintOptions:
    style: int = 0        # 0 sketsa lalu warna, 1 langsung warna, 2 sketsa saja, 3 langsung warna ikuti garis
    direction: int = 3    # 0 kiri-kanan, 1 atas-bawah, 2 tengah keluar, 3 acak alami
    paper: int = 0
    ratio: int = 0        # 0 sesuai foto, 1 9:16, 2 1:1, 3 16:9
    res: int = 720
    hand_pct: int = 55
    hand_speed: float = 1.0
    hold_sec: int = 1
    fps: int = 30
    sens: int = 0
    thick: int = 0
    source: int = 0
    ink: int = 0
    transparent_src: bool = False


def _gray(a):
    return (a[..., 0].astype(np.int32) * 3 + a[..., 1].astype(np.int32) * 6 + a[..., 2].astype(np.int32)) // 10


def _draw_paper(w, h, paper):
    img = np.empty((h, w, 3), np.uint8)
    img[:] = PAPER[paper]
    if paper == 3:
        sp = max(16.0, h / 32.0)
        lw = max(1, int(w / 600))
        y = sp * 3.2
        while y < h - sp * 0.5:
            cv2.line(img, (int(w * 0.07), int(y)), (int(w * 0.97), int(y)), (0xCC, 0xBF, 0xB9), lw)
            y += sp
        hy = sp * 3.2
        while hy < h - sp:
            c = (int(w * 0.028), int(hy))
            r = int(w * 0.017)
            cv2.circle(img, c, r, (0xEE, 0xEA, 0xE9), -1, cv2.LINE_AA)
            cv2.circle(img, c, r, (0xD4, 0xCC, 0xC9), max(1, int(w / 500)), cv2.LINE_AA)
            hy += sp * 1.7
    return img


def _is_line_art(px, x0, y0, x1, y1):
    sub = px[y0:y1:3, x0:x1:3, :3].astype(np.int32)
    if sub.size == 0:
        return False
    d = sub.max(2) - sub.min(2)
    return (d < 24).mean() > 0.96


def _otsu(hist, total):
    sum_all = float((np.arange(len(hist)) * hist).sum())
    wB = 0.0
    sumB = 0.0
    best = -1.0
    thr = 0
    for t in range(len(hist)):
        wB += hist[t]
        if wB == 0:
            continue
        wF = total - wB
        if wF <= 0:
            break
        sumB += t * hist[t]
        mB = sumB / wB
        mF = (sum_all - sumB) / wF
        v = wB * wF * (mB - mF) ** 2
        if v > best:
            best, thr = v, t
    return thr


def _dark_mask(plain, rx0, ry0, rx1, ry1, sens):
    g = _gray(plain)
    sub = g[ry0:ry1, rx0:rx1]
    hist = np.bincount(sub.ravel(), minlength=256).astype(np.float64)
    thr = int(np.clip(_otsu(hist, sub.size), 40, 128))
    if sens == 1:
        thr = int(thr * 0.75)
    if sens == 2:
        thr = min(160, int(thr * 1.25))
    m = np.zeros(g.shape, bool)
    m[ry0:ry1, rx0:rx1] = sub < thr
    return m


def _edge_mask(plain, sens):
    g0 = _gray(plain).astype(np.float32)
    g = cv2.blur(g0, (3, 3), borderType=cv2.BORDER_REPLICATE)
    gx = cv2.Sobel(g, cv2.CV_32F, 1, 0, ksize=3, borderType=cv2.BORDER_REPLICATE)
    gy = cv2.Sobel(g, cv2.CV_32F, 0, 1, ksize=3, borderType=cv2.BORDER_REPLICATE)
    mag = np.minimum(1023, (np.abs(gx) + np.abs(gy))).astype(np.int32)
    mag[:2] = mag[-2:] = 0
    mag[:, :2] = mag[:, -2:] = 0
    inner = mag[2:-2, 2:-2]
    hist = np.bincount(inner.ravel(), minlength=1024).astype(np.float64)
    tot = inner.size
    thr = int(np.clip(_otsu(hist, tot), 40, 250))
    above = np.cumsum(hist[::-1])[::-1]          # above[t] = jumlah >= t

    def frac(t):
        return above[t + 1] / tot if t + 1 < 1024 else 0.0

    while thr < 600 and frac(thr) > 0.12:
        thr += 5
    while thr > 25 and frac(thr) < 0.015:
        thr -= 5
    if sens == 1:
        thr = int(thr * 1.6)
    if sens == 2:
        thr = max(20, int(thr * 0.6))
    return mag > thr


def _trace_strokes(mask, order, min_run=15):
    """Urutan piksel mengikuti goresan (DFS lurus-dulu). order = urutan titik awal."""
    h, w = mask.shape
    flat = mask.ravel()
    visited = np.zeros(h * w, bool)
    dxs = (-1, 0, 1, -1, 1, -1, 0, 1)
    dys = (-1, -1, -1, 0, 0, 1, 1, 1)
    seq = []
    starts = order[flat[order]]
    mv = memoryview(flat.view(np.uint8))
    vis = visited
    for start in starts.tolist():
        if vis[start]:
            continue
        comp = len(seq)
        stack = [(start, start)]
        while stack:
            p, par = stack.pop()
            if vis[p]:
                continue
            vis[p] = True
            seq.append(p)
            x, y = p % w, p // w
            ddx, ddy = x - par % w, y - par // w
            cand = []
            for k in range(8):
                nx, ny = x + dxs[k], y + dys[k]
                if nx < 0 or ny < 0 or nx >= w or ny >= h:
                    continue
                q = ny * w + nx
                if not mv[q] or vis[q]:
                    continue
                cand.append((dxs[k] * ddx + dys[k] * ddy, q))
            cand.sort(key=lambda t: t[0])           # skor kecil dulu ditumpuk, besar paling akhir (diambil pertama)
            for _, q in cand:
                stack.append((q, p))
        if len(seq) - comp < min_run:
            del seq[comp:]
    return np.array(seq, np.int64)


def _trace_natural(mask, gray, order, rnd, cell, cell_order):
    h, w = mask.shape
    n = h * w
    m8 = mask.astype(np.uint8)
    core = cv2.erode(m8, np.ones((3, 3), np.uint8), borderType=cv2.BORDER_CONSTANT, borderValue=0).astype(bool)
    core[0] = core[-1] = False
    core[:, 0] = core[:, -1] = False
    dense = cv2.dilate(core.astype(np.uint8), np.ones((3, 3), np.uint8)).astype(bool) & mask
    dense[0] = dense[-1] = False
    dense[:, 0] = dense[:, -1] = False
    dense_count = int(dense.sum())
    thin = mask & ~dense

    if cell is not None and cell_order is not None and len(cell_order) > 0:
        parts = [_trace_strokes(thin & (cell == c), order, 4) for c in cell_order]
        rank_of = {c: r for r, c in enumerate(cell_order)}
    else:
        parts = [_trace_strokes(thin, order)]
        rank_of = None
    if dense_count == 0:
        return np.concatenate(parts) if parts else np.zeros(0, np.int64)

    g = gray.astype(np.float32)
    gx = np.zeros_like(g)
    gy = np.zeros_like(g)
    gx[1:-1, 1:-1] = g[1:-1, 2:] - g[1:-1, :-2]
    gy[1:-1, 1:-1] = g[2:, 1:-1] - g[:-2, 1:-1]
    br = max(3, max(w, h) // 150)
    k = 2 * br + 1
    jxx = cv2.blur(gx * gx, (k, k), borderType=cv2.BORDER_REPLICATE)
    jyy = cv2.blur(gy * gy, (k, k), borderType=cv2.BORDER_REPLICATE)
    jxy = cv2.blur(gx * gy, (k, k), borderType=cv2.BORDER_REPLICATE)
    ang0 = rnd.random() * math.pi
    c0, s0 = math.cos(2 * ang0), math.sin(2 * ang0)
    a = jxx - jyy
    b = 2 * jxy
    bias = 0.25 * (jxx + jyy) + 150.0
    phi = 0.5 * np.arctan2(-b + bias * s0, -a + bias * c0)
    fxa = np.cos(phi).ravel()
    fya = np.sin(phi).ravel()

    dflat = dense.ravel()
    visited = np.zeros(n, bool)
    half = int(np.clip(max(w, h) // 55, 8, 28))

    def walk(sx, sy, sign):
        x, y = float(sx), float(sy)
        s0i = sy * w + sx
        dx, dy = fxa[s0i] * sign, fya[s0i] * sign
        buf = []
        vrun = 0
        last = s0i
        guard = 0
        while len(buf) < half and guard < half * 3:
            guard += 1
            x += dx
            y += dy
            ix, iy = int(x + 0.5), int(y + 0.5)
            if ix <= 0 or iy <= 0 or ix >= w - 1 or iy >= h - 1:
                break
            p = iy * w + ix
            if not dflat[p]:
                break
            nx, ny = fxa[p], fya[p]
            if nx * dx + ny * dy < 0:
                nx, ny = -nx, -ny
            dx = 0.75 * dx + 0.25 * nx
            dy = 0.75 * dy + 0.25 * ny
            m = math.hypot(dx, dy)
            if m < 1e-3:
                break
            dx /= m
            dy /= m
            if p == last:
                continue
            last = p
            if visited[p]:
                vrun += 1
                if vrun >= 3:
                    break
                continue
            vrun = 0
            visited[p] = True
            buf.append(p)
        return buf

    seq_d = []
    seg_end = [0] * len(parts)
    rr = 0
    for start in order[dflat[order]].tolist():
        if visited[start]:
            continue
        if rank_of is not None:
            rk = rank_of[int(cell[start // w, start % w])]
            while rr < rk:
                seg_end[rr] = len(seq_d)
                rr += 1
        sx, sy = start % w, start // w
        visited[start] = True
        nb = walk(sx, sy, -1.0)
        nf = walk(sx, sy, 1.0)
        seq_d.extend(reversed(nb))
        seq_d.append(start)
        seq_d.extend(nf)
    while rr < len(parts):
        seg_end[rr] = len(seq_d)
        rr += 1
    seq_d = np.array(seq_d, np.int64)
    res = []
    prev = 0
    for r in range(len(parts)):
        res.append(parts[r])
        res.append(seq_d[prev:seg_end[r]])
        prev = seg_end[r]
    return np.concatenate(res)


def _grow_fill(seq, w, h, fallback):
    if len(seq) == 0:
        return fallback
    n = w * h
    seen = np.zeros(n, bool)
    seen[seq] = True
    out = [seq]
    frontier = seq
    while True:
        x = frontier % w
        nb = []
        nb.append(frontier[x > 0] - 1)
        nb.append(frontier[x < w - 1] + 1)
        nb.append(frontier[frontier >= w] - w)
        nb.append(frontier[frontier < n - w] + w)
        cand = np.concatenate(nb)
        cand = cand[~seen[cand]]
        if len(cand) == 0:
            break
        cand = np.unique(cand)[np.argsort(np.random.permutation(len(np.unique(cand))))] if False else np.unique(cand)
        seen[cand] = True
        out.append(cand)
        frontier = cand
    res = np.concatenate(out)
    return res if len(res) == n else fallback


def _stamp_idx(arr, idx, h, w, r, colors):
    """Cap kotak (r+1)x(r+1) di tiap indeks. colors: (N,3) atau (3,)."""
    y = idx // w
    x = idx % w
    for dy in range(r + 1):
        for dx in range(r + 1):
            yy = y + dy
            xx = x + dx
            ok = (yy < h) & (xx < w)
            arr[yy[ok], xx[ok]] = colors[ok] if getattr(colors, "ndim", 1) == 2 else colors


def render(src: np.ndarray, seconds: int, out_path: str, o: PaintOptions, hand=None,
           cancelled=lambda: False, on_progress=lambda p: None) -> None:
    import imageio_ffmpeg

    src = to_rgba(src)
    sh, sw_ = src.shape[:2]
    fps = o.fps
    total = seconds * fps
    r = o.res
    if o.ratio == 1:
        w0, h0 = r * 9 // 16, r
    elif o.ratio == 2:
        w0, h0 = r, r
    elif o.ratio == 3:
        w0, h0 = r, r * 9 // 16
    else:
        sc = r / max(sw_, sh)
        w0, h0 = int(sw_ * sc), int(sh * sc)
    w, h = w0 & ~1, h0 & ~1
    n = w * h

    paper_img = _draw_paper(w, h, o.paper)
    s = min(w / sw_, h / sh)
    dw, dh = sw_ * s, sh * s
    px0, py0 = int(round((w - dw) / 2)), int(round((h - dh) / 2))
    pw, ph = max(1, int(round(dw))), max(1, int(round(dh)))
    px0 = min(px0, w - 1)
    py0 = min(py0, h - 1)
    pw, ph = min(pw, w - px0), min(ph, h - py0)
    scaled = cv2.resize(src, (pw, ph), interpolation=cv2.INTER_AREA if s < 1 else cv2.INTER_LINEAR).astype(np.float32)
    alpha_s = scaled[..., 3:4] / 255.0

    # warna: foto dilebur ke kertas (multiply) / ditimpa langsung (papan tulis)
    color = paper_img.astype(np.float32)
    plain = np.full((h, w, 3), 255.0, np.float32)
    reg = (slice(py0, py0 + ph), slice(px0, px0 + pw))
    plain[reg] = scaled[..., :3] * alpha_s + 255.0 * (1 - alpha_s)
    transp = o.transparent_src
    if transp:
        if o.paper != 2:
            color = color * plain / 255.0
        else:
            color[reg] = scaled[..., :3] * alpha_s + color[reg] * (1 - alpha_s)
    elif o.paper == 2:
        color[reg] = scaled[..., :3]
    else:
        color[reg] = color[reg] * scaled[..., :3] / 255.0
    color = np.clip(color, 0, 255).astype(np.uint8)
    plain = np.clip(plain, 0, 255).astype(np.uint8)
    paper_img = paper_img.astype(np.uint8)

    use_seq = o.style != 1
    rx0, ry0 = int(np.clip(px0, 0, w - 1)), int(np.clip(py0, 0, h - 1))
    rx1, ry1 = int(np.clip(px0 + pw, rx0 + 1, w)), int(np.clip(py0 + ph, ry0 + 1, h))

    if transp:
        if o.paper == 2:
            alpha_arr = np.zeros((h, w), np.int32)
            alpha_arr[reg] = scaled[..., 3].astype(np.int32)
        else:
            alpha_arr = np.clip(255 - _gray(plain), 0, 255)
    else:
        alpha_arr = None

    dark = False
    if use_seq and not transp:
        dark = {1: False, 2: True}.get(o.source, _is_line_art(plain, rx0, ry0, rx1, ry1))
    if not use_seq:
        mask = np.zeros((h, w), bool)
    elif transp:
        mask = alpha_arr > (30 if o.paper == 2 else 24)
    elif dark:
        mask = _dark_mask(plain, rx0, ry0, rx1, ry1, o.sens)
    else:
        mask = _edge_mask(plain, o.sens)
    if use_seq and not dark and not transp:
        keep = np.zeros_like(mask)
        keep[ry0 + 3:ry1 - 3, rx0 + 3:rx1 - 3] = True
        mask &= keep
    frac = mask.sum() / n
    if transp:
        br = 0
    elif o.thick in (1, 2, 3):
        br = {1: 0, 2: 1, 3: 2}[o.thick]
    elif dark:
        br = 0
    else:
        r0 = int(round(max(w, h) / 540.0))
        if frac > 0.10:
            r0 -= 1
        if frac < 0.03:
            r0 += 1
        br = int(np.clip(r0, 0, 2))

    rnd = random.Random()
    dir_mode = 6 if o.direction == 3 else o.direction
    ink_total = int(mask.sum())
    if dir_mode == 6 and ink_total < 200:
        dir_mode = 4
    regional = dir_mode == 6
    sweep = {0: 0.0, 1: math.pi / 2, 4: rnd.random() * 2 * math.pi}.get(dir_mode, 0.0)
    radial = dir_mode in (2, 5)
    cx, cy = w / 2.0, h / 2.0
    maxd = max(math.hypot(cx, cy), math.hypot(w - cx, cy), math.hypot(cx, h - cy), math.hypot(w - cx, h - cy))
    ca, sa = math.cos(sweep), math.sin(sweep)
    pmin = min(0, w * ca, h * sa, w * ca + h * sa)
    pmax = max(0, w * ca, h * sa, w * ca + h * sa)
    pspan = max(1.0, pmax - pmin)
    buckets = 2000
    yy, xx = np.mgrid[0:h, 0:w]
    nrng = np.random.default_rng(rnd.getrandbits(32))
    cell = None
    cell_order = None
    if regional:
        k_cells = 5 + rnd.randrange(4)
        ys_, xs_ = np.nonzero(mask)
        stride = max(1, ink_total // 3000)
        sxs, sys_ = xs_[::stride][:3000].astype(np.float32), ys_[::stride][:3000].astype(np.float32)
        md = np.full(len(sxs), np.inf, np.float32)
        cur_i = rnd.randrange(len(sxs))
        seeds = []
        for _ in range(k_cells):
            seeds.append((sxs[cur_i], sys_[cur_i]))
            d = (sxs - sxs[cur_i]) ** 2 + (sys_ - sys_[cur_i]) ** 2
            md = np.minimum(md, d)
            cur_i = int(np.argmax(md))
        dist = np.stack([(xx - sx) ** 2 + (yy - sy) ** 2 for sx, sy in seeds], 0)
        cell = np.argmin(dist, 0)
        perm = list(range(k_cells))
        rnd.shuffle(perm)
        rank_of = np.zeros(k_cells, np.int32)
        for rk, c in enumerate(perm):
            rank_of[c] = rk
        ang = np.array([rnd.random() * 2 * math.pi for _ in range(k_cells)], np.float32)
        proj = xx * np.cos(ang)[cell] + yy * np.sin(ang)[cell]
        pmn = np.array([proj[cell == k].min() if (cell == k).any() else 0 for k in range(k_cells)])
        pmx = np.array([proj[cell == k].max() if (cell == k).any() else 1 for k in range(k_cells)])
        b = np.clip((proj - pmn[cell]) / np.maximum(1.0, (pmx - pmn)[cell]), 0, 1) * 0.94 + nrng.random((h, w)) * 0.06
        key = np.clip(((rank_of[cell] + np.clip(b, 0, 1)) / k_cells * (buckets - 1)).astype(np.int64), 0, buckets - 1)
        cell_order = perm
    else:
        if radial:
            d = np.hypot(xx - cx, yy - cy) / maxd
            b = 1.0 - d if dir_mode == 5 else d
        else:
            b = (xx * ca + yy * sa - pmin) / pspan
        key = ((np.clip(b, 0, 1) * 0.94 + nrng.random((h, w)) * 0.06) * (buckets - 1)).astype(np.int64)
    order = np.argsort(key.ravel(), kind="stable")

    if use_seq:
        flow_gray = _gray(color if transp else plain)
        seq = _trace_natural(mask, flow_gray, order, rnd, cell, cell_order)
    else:
        seq = np.zeros(0, np.int64)

    if o.paper == 2 and 1 <= o.ink <= 3:
        ink_fixed = np.array(INK[2], np.uint8)
    elif o.ink == 1:
        ink_fixed = np.array((0x1F, 0x2A, 0x8C), np.uint8)
    elif o.ink == 2:
        ink_fixed = np.array((0x5A, 0x3A, 0x22), np.uint8)
    elif o.ink == 3:
        ink_fixed = np.array((0x4A, 0x4A, 0x4A), np.uint8)
    else:
        ink_fixed = np.array(INK[o.paper], np.uint8)

    pf = paper_img.reshape(-1, 3)
    colf = color.reshape(-1, 3)
    plf = plain.reshape(-1, 3)

    def ink_at(idx):
        if transp and o.ink in (0, 4):
            return colf[idx]
        if transp:
            t = (alpha_arr.ravel()[idx] / 255.0)[:, None]
            return np.clip(pf[idx] * (1 - t) + ink_fixed * t, 0, 255).astype(np.uint8)
        if o.ink == 4:
            return plf[idx]
        return np.broadcast_to(ink_fixed, (len(idx), 3))

    sketch_final = paper_img.copy()
    if len(seq):
        _stamp_idx(sketch_final, seq, h, w, br, ink_at(seq))
    fill_mode = o.style == 3
    trace = _grow_fill(seq, w, h, order) if fill_mode else seq

    cur = paper_img.copy()
    hs = None
    if hand is not None:
        hw = max(8, int(w * o.hand_pct / 100.0))
        hand = to_rgba(hand)
        hs = cv2.resize(hand, (hw, max(1, hand.shape[0] * hw // hand.shape[1])), interpolation=cv2.INTER_AREA)
        hs_rgb = hs[..., :3].astype(np.float32)
        hs_a = hs[..., 3:4].astype(np.float32) / 255.0

    bitrate = (8_000_000 if max(w, h) >= 1000 else 4_000_000) * (3 if fps > 30 else 2) // 2
    ff = imageio_ffmpeg.get_ffmpeg_exe()
    cmd = [ff, "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{w}x{h}", "-r", str(fps),
           "-i", "-", "-an", "-c:v", "libx264", "-preset", "veryfast", "-b:v", str(bitrate),
           "-pix_fmt", "yuv420p", "-movflags", "+faststart", out_path]
    flags = subprocess.CREATE_NO_WINDOW if hasattr(subprocess, "CREATE_NO_WINDOW") else 0
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stderr=subprocess.PIPE, creationflags=flags)

    hold = min(o.hold_sec * fps, total // 2)
    s2 = max(2, total - hold)
    half = max(1, s2 * 65 // 100) if o.style == 0 else s2
    final_img = sketch_final if o.style == 2 else color
    rev = 0
    hx = hy = 0.0
    started = False
    try:
        for f in range(total):
            if cancelled():
                break
            drawing = True
            tt = f * 30.0 / fps
            if o.style == 0 and f == half:
                rev = 0
            frm = rev
            tx, ty = hx, hy
            fresh = False
            if f < s2:
                in_first = f < half
                start = 0 if in_first else half
                length = half if in_first else s2 - half
                if in_first and use_seq:
                    t = len(trace) * (f - start + 1) // length
                    if t > rev:
                        idx = trace[rev:t]
                        if fill_mode:
                            cur.reshape(-1, 3)[idx] = colf[idx]
                        else:
                            _stamp_idx(cur, idx, h, w, br, ink_at(idx))
                    rev = t
                    if rev > frm:
                        last = int(trace[rev - 1])
                        tx, ty, fresh = float(last % w), float(last // w), True
                else:
                    t = n * (f - start + 1) // length
                    if t > rev:
                        idx = order[rev:t]
                        cur.reshape(-1, 3)[idx] = colf[idx]
                    rev = t
                    if rev > frm:
                        k = min(rev - frm, 50)
                        step = max(1, (rev - frm) // k)
                        ids = order[[rev - 1 - q * step for q in range(k)]]
                        px_ = float((ids % w).mean())
                        py_ = float((ids // w).mean())
                        wob = math.sin(tt * 0.9 * o.hand_speed)
                        if regional:
                            wb = 0.03 * min(w, h)
                            px_ += wb * math.cos(tt * 1.7 * o.hand_speed)
                            py_ += wb * math.sin(tt * 2.3 * o.hand_speed)
                        elif radial:
                            fr = rev / n
                            rad = (1 - fr if dir_mode == 5 else fr) * maxd * 0.8
                            a2 = tt * 0.35 * o.hand_speed
                            px_, py_ = cx + rad * math.cos(a2), cy + rad * math.sin(a2)
                        else:
                            aa = px_ * ca + py_ * sa
                            ext = abs(w * sa) + abs(h * ca)
                            bb = (-w * 0.5 * sa + h * 0.5 * ca) + 0.4 * ext * wob
                            px_, py_ = aa * ca - bb * sa, aa * sa + bb * ca
                        tx, ty, fresh = px_, py_, True
            else:
                drawing = False
                cur[:] = final_img
            if fresh:
                if not started:
                    hx, hy, started = tx, ty, True
                else:
                    k2 = min(1.0, 0.45 * min(o.hand_speed, 2.0) * 30.0 / fps)
                    hx += (tx - hx) * k2
                    hy += (ty - hy) * k2
            if hs is not None and drawing and started:
                frame = cur.copy()
                x0 = int(np.clip(hx, 0, w))
                y0 = int(hy - 0.96 * hs.shape[0])
                _paste(frame, hs_rgb, hs_a, x0, y0)
            else:
                frame = cur
            proc.stdin.write(frame.tobytes())
            on_progress(f * 100 // total)
        proc.stdin.close()
        err = proc.stderr.read().decode(errors="ignore")
        proc.wait()
        if proc.returncode not in (0, None) and not cancelled():
            raise RuntimeError("FFmpeg gagal: " + err[-300:])
    finally:
        if proc.poll() is None:
            proc.kill()


def _paste(frame, rgb, a, x0, y0):
    h, w = frame.shape[:2]
    hh, hw = rgb.shape[:2]
    xa, ya = max(0, x0), max(0, y0)
    xb, yb = min(w, x0 + hw), min(h, y0 + hh)
    if xb <= xa or yb <= ya:
        return
    sr = rgb[ya - y0:yb - y0, xa - x0:xb - x0]
    sa = a[ya - y0:yb - y0, xa - x0:xb - x0]
    dst = frame[ya:yb, xa:xb].astype(np.float32)
    frame[ya:yb, xa:xb] = np.clip(sr * sa + dst * (1 - sa), 0, 255).astype(np.uint8)


def default_hand():
    from PIL import Image
    return np.array(Image.open(asset_path("hand.png")).convert("RGBA"))
