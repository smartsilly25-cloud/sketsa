"""Format persegi 1:1 tanpa memotong objek (port dari SquareExtend.kt)."""
from __future__ import annotations

from dataclasses import dataclass

import cv2
import numpy as np

from .common import box_blur, smoothstep, to_rgba

VIGNETTE = 0.60
RAMP = 0.10
W0 = 0.92


@dataclass
class Extended:
    img: np.ndarray
    ox: int
    oy: int
    w: int
    h: int
    changed: bool


def apply(src: np.ndarray, fill: int) -> Extended:
    """fill 1 = perluas latar (blur memudar ke kertas), fill 2 = kertas polos."""
    src = to_rgba(src)
    h, w = src.shape[:2]
    s = max(w, h)
    if abs(w - h) <= s * 0.03:
        return Extended(src, 0, 0, w, h, False)
    ox = (s - w) // 2
    oy = (s - h) // 2
    out = np.full((s, s, 4), 255, np.uint8)
    if fill != 2:
        sm_ = min(s, 300)
        ys = np.clip(((np.arange(sm_) + 0.5) * s / sm_ - oy).astype(int), 0, h - 1)
        xs = np.clip(((np.arange(sm_) + 0.5) * s / sm_ - ox).astype(int), 0, w - 1)
        small = src[..., :3][ys][:, xs].astype(np.float32)
        for c in range(3):
            small[..., c] = box_blur(small[..., c], 16, passes=2)
        bb = cv2.resize(small, (s, s), interpolation=cv2.INTER_LINEAR)

        yy, xx = np.mgrid[0:s, 0:s]
        dy = np.maximum(np.maximum(oy - yy, yy - (oy + h - 1)), 0).astype(np.float32)
        dx = np.maximum(np.maximum(ox - xx, xx - (ox + w - 1)), 0).astype(np.float32)
        d = np.sqrt(dx * dx + dy * dy)
        ex = src[..., :3][np.clip(yy - oy, 0, h - 1), np.clip(xx - ox, 0, w - 1)].astype(np.float32)
        ramp = max(1.0, RAMP * s)
        far = float(max(max(ox, oy), 1))
        t = np.clip(d / ramp, 0, 1)
        wgt = (W0 + (1 - W0) * (t * t * (3 - 2 * t)))[..., None]
        tv = np.clip(d / far, 0, 1)
        f = (VIGNETTE * (tv * tv * (3 - 2 * tv)))[..., None]
        col = (ex * (1 - wgt) + bb * wgt) * (1 - f) + 255.0 * f
        out[..., :3] = np.clip(np.floor(col + 0.5), 0, 255).astype(np.uint8)
    out[oy:oy + h, ox:ox + w] = src                      # foto asli tetap utuh
    return Extended(out, ox, oy, w, h, True)


def crop_back(full: np.ndarray, ex: Extended) -> np.ndarray:
    """Ambil kembali bagian foto asli dari sketsa persegi."""
    r = full.shape[1] / ex.img.shape[1]
    H, W = full.shape[:2]
    x = int(np.clip(round(ex.ox * r), 0, W - 1))
    y = int(np.clip(round(ex.oy * r), 0, H - 1))
    w2 = max(1, min(round(ex.w * r), W - x))
    h2 = max(1, min(round(ex.h * r), H - y))
    return full[y:y + h2, x:x + w2].copy()


def pad_to_square(b: np.ndarray) -> np.ndarray:
    """Taruh hasil potongan di kanvas persegi transparan, tanpa memotong."""
    h, w = b.shape[:2]
    if w == h:
        return b
    s = max(w, h)
    out = np.zeros((s, s, 4), np.uint8)
    out[(s - h) // 2:(s - h) // 2 + h, (s - w) // 2:(s - w) // 2 + w] = b
    return out
