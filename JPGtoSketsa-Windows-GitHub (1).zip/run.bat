@echo off
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>nul && (set PY=py -3) || (set PY=python)
if not exist .venv (
  echo Pertama kali: menyiapkan lingkungan (butuh internet, 2-5 menit)...
  %PY% -m venv .venv || (echo Python 3.10+ belum terpasang. Unduh di python.org lalu centang "Add to PATH". & pause & exit /b 1)
  call .venv\Scripts\activate.bat
  python -m pip install --upgrade pip
  pip install -r requirements.txt || (echo Gagal memasang paket. & pause & exit /b 1)
) else (
  call .venv\Scripts\activate.bat
)
python main.py
if errorlevel 1 pause
